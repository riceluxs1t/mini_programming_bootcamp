// $( document ).ready(function() {
//     var isPreviewMode = false;
//     $("#preview-button").on('click', function () {
//         if (isPreviewMode)
//         {
//             $('.hideforpreview').show();
//             isPreviewMode = ~isPreviewMode;
//         }
//         else
//         {
//             $('.hideforpreview').hide();
//             isPreviewMode = ~isPreviewMode;
//         }
//     });
// });